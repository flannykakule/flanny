<?php
/**
 * Plugin Name: Custom Utilities
 * Description: Adds shortcodes, settings, and post filters.
 * Version: 1.0
 */

require_once plugin_dir_path(__FILE__) . 'includes/shortcodes.php';
require_once plugin_dir_path(__FILE__) . 'includes/filters.php';
require_once plugin_dir_path(__FILE__) . 'admin/settings-page.php';
