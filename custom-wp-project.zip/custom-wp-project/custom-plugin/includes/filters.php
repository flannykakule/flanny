<?php
// Append message after post content
function append_custom_footer_to_posts($content) {
    if (is_single() && in_the_loop() && is_main_query()) {
        $footer = get_option('custom_message', 'Thanks for reading!');
        $content .= '<div class="post-footer-note">' . esc_html($footer) . '</div>';
    }
    return $content;
}
add_filter('the_content', 'append_custom_footer_to_posts');
