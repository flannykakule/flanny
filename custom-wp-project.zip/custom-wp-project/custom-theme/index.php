<?php get_header(); ?>
<main id="site-main">
    <h1><?php bloginfo('name'); ?></h1>
    <p><?php bloginfo('description'); ?></p>
</main>
<?php get_footer(); ?>
