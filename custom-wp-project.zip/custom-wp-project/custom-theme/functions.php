<?php
// Enqueue scripts and styles
function custom_theme_enqueue_scripts() {
    wp_enqueue_style('custom-style', get_template_directory_uri() . '/assets/css/style.css');
    wp_enqueue_script('custom-script', get_template_directory_uri() . '/assets/js/main.js', [], false, true);
}
add_action('wp_enqueue_scripts', 'custom_theme_enqueue_scripts');

// Register ACF blocks
if (function_exists('acf_register_block_type')) {
    add_action('acf/init', function () {
        acf_register_block_type([
            'name' => 'hero',
            'title' => __('Hero Block', 'custom'),
            'render_template' => 'template-parts/blocks/hero.php',
            'category' => 'layout',
            'icon' => 'cover-image',
            'keywords' => ['hero', 'banner'],
        ]);
    });
}
