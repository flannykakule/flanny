# 🛠 Developer Documentation: Custom Theme & Plugin

## Overview

This project includes:

- A **custom WordPress theme** (`custom`) built with:
  - ACF block-based architecture
  - Gutenberg support
  - Responsive, accessible layout based on provided Figma design

- A **reusable plugin** (`custom-utilities`) providing:
  - Shortcodes
  - Admin settings page
  - Post content filters

## 📁 File Structure

```
custom-wp-project/
├── custom-theme/           # WordPress theme folder
│   ├── assets/
│   ├── blocks/
│   ├── components/
│   ├── template-parts/
│   │   └── blocks/
│   ├── functions.php
│   ├── style.css
│   ├── index.php
│   ├── header.php
│   └── footer.php
└── custom-plugin/          # WordPress plugin folder
    ├── custom-utilities.php
    ├── includes/
    │   ├── shortcodes.php
    │   └── filters.php
    └── admin/
        └── settings-page.php
```

## 📦 Theme: `custom-theme`

### ✅ Key Files

#### `style.css`
Declares theme metadata and is required by WordPress.

#### `functions.php`
Enqueues scripts and styles, registers ACF blocks.

#### Template Files
- `index.php`, `header.php`, `footer.php` — core layout
- `template-parts/blocks/` — reusable ACF block templates

## 📦 Plugin: `custom-utilities`

### ✅ Purpose
A utility plugin providing reusable logic independent of the theme.

### 🔌 Entry Point: `custom-utilities.php`
Includes shortcode, filter, and admin logic.

### 🧩 Shortcodes
```php
[custom_cta]
[custom_message]
```

### 📝 Content Filter
Appends content to post using `the_content` filter.

### ⚙️ Admin Settings Page
Configurable message for shortcodes and filters.

## 🚀 Setup Instructions

```bash
git clone https://github.com/your-username/custom-wp-project.git

# Copy folders to WordPress wp-content
mv custom-theme/ wp-content/themes/custom
mv custom-plugin/ wp-content/plugins/custom-utilities
```

## 📈 Future Enhancements

- Add CPT and taxonomies
- More ACF blocks from Figma
- Tailwind/SCSS integration
- GitHub Actions for CI/CD

