<?php
function custom_utilities_menu() {
    add_options_page(
        'Custom Settings',
        'Custom Settings',
        'manage_options',
        'custom-utilities-settings',
        'custom_utilities_settings_page'
    );
}
add_action('admin_menu', 'custom_utilities_menu');

function custom_utilities_settings_page() {
    ?>
    <div class="wrap">
        <h1>Custom Plugin Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('custom_utilities_group');
            do_settings_sections('custom-utilities-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function custom_utilities_register_settings() {
    register_setting('custom_utilities_group', 'custom_message');

    add_settings_section('main_section', 'Main Settings', null, 'custom-utilities-settings');

    add_settings_field(
        'custom_message',
        'Custom Message',
        'custom_message_field_callback',
        'custom-utilities-settings',
        'main_section'
    );
}
add_action('admin_init', 'custom_utilities_register_settings');

function custom_message_field_callback() {
    $value = get_option('custom_message', '');
    echo '<input type="text" name="custom_message" value="' . esc_attr($value) . '" class="regular-text">';
}
