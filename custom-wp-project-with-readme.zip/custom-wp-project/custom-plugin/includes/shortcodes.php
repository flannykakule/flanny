<?php
// CTA shortcode
function custom_cta_shortcode() {
    return '<div class="custom-cta"><a href="/register" class="btn">Register Now</a></div>';
}
add_shortcode('custom_cta', 'custom_cta_shortcode');

// Message from admin settings
function custom_message_shortcode() {
    $message = get_option('custom_message', 'Default message');
    return '<div class="custom-message">' . esc_html($message) . '</div>';
}
add_shortcode('custom_message', 'custom_message_shortcode');
