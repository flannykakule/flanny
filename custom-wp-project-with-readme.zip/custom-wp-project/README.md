# Custom WordPress Project

This repository contains a custom WordPress theme and plugin built with a component-based architecture using ACF and Gutenberg. The design follows modern accessibility and responsiveness best practices, and matches a provided Figma specification.

---

## 📦 Contents

### `custom-theme/`
- A custom WordPress theme
- Uses ACF Pro to register reusable Gutenberg blocks
- Includes base layout files and enqueue setup
- Responsive and accessible styling architecture

### `custom-plugin/`
- A utility plugin
- Adds:
  - Shortcodes (`[custom_cta]`, `[custom_message]`)
  - Admin Settings page (under **Settings → Custom Settings**)
  - Filter to append message after post content

---

## 🚀 Installation

1. Clone the repo:

```bash
git clone https://github.com/your-username/custom-wp-project.git
```

2. Move the theme and plugin into WordPress:

```bash
mv custom-theme/ wp-content/themes/custom
mv custom-plugin/ wp-content/plugins/custom-utilities
```

3. Activate the theme and plugin in the WordPress admin panel.

---

## 🛠 Requirements

- WordPress 6.x
- ACF Pro (for block registration)
- PHP 7.4 or later

---

## 📌 Shortcodes

- `[custom_cta]` — Renders a CTA button
- `[custom_message]` — Displays a message from the admin settings

---

## 📝 Admin Settings Page

Navigate to:
``Settings → Custom Settings``

Configure the message shown by the shortcode and content filter.

---

## 📂 Developer Notes

See [`DEVELOPMENT.md`](./DEVELOPMENT.md) for full technical documentation on how this project was built, including code structure and extension points.

---

## 🧩 Based On

Design inspired by [Figma Layout](https://www.figma.com/design/MCqnZoZ0N5YxX1bBrqQSIF/Design---Dev-Task?node-id=0-1)

---

## 📄 License

MIT — free to use, modify, and distribute.
